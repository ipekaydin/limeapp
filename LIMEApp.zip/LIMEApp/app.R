# Stat 292 - Final Project - Group LIME
# LIMEApp
# Levent Sarı - 2290930
# İpek Aydın - 2290526
# Miray Çınar - 2290609
# Ecenaz Tunç - 2290971
library(shiny)
library(shinyWidgets)
require(ggplot2)
library(sqldf)
library(tidyverse)
library(gridExtra)
library(quantreg)
library(OpenStreetMap)
library(leaflet)
library(rworldmap)
library(maps)
library(plyr)
library(RgoogleMaps)
library(ggmap)
library(mapproj)
library(sf)
library(dplyr)
library(devtools)
library(countrycode)
alcohap <- read.csv("HappinessAlcoholConsumption.csv",header=T)
temptemp <- sqldf("select Beer_PerCapita, Spirit_PerCapita, Wine_PerCapita from alcohap")
temptemp$Total_PerCapita = temptemp %>% 
    apply(.,1,sum)
alcohap$Total_PerCapita = temptemp$Total_PerCapita


ui <- fluidPage(setBackgroundColor(
    color = c("#98F589","#F5F489"),gradient = "linear",
    direction = "bottom"),
    tags$style(type = 'text/css', '.navbar { background-color: #B9F9F3;
                                               color: #000000;
                                               font-family: Barlow;
                                               font-size: 14px;
                                               font-weight: black;}',
               
               '.navbar-dropdown { background-color: #B9F9F3;
                                                    color: #000000;
                                                    font-family: Barlow;
                                                    font-size: 14px;
                                                    font-weight: black;}'),
    navbarPage("LIME App",
               tabPanel("Welcome!", fluid = TRUE,
                        htmlOutput("picture1"),
                        htmlOutput("pictureapp"),
                        HTML('<iframe width="560" height="315" src="https://www.youtube.com/embed/B-EmeQg40wE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>')
               ),
               tabPanel("View the Data",fluid=TRUE,
                        sidebarLayout(
                            sidebarPanel(checkboxGroupInput("input2","Select the Variables You Would Like to See",colnames(alcohap))),
                            mainPanel(
                                htmlOutput("picture3"),
                                verbatimTextOutput("text2")
                                ))),
               tabPanel("Analysis - Findings", fluid = TRUE,
                        selectInput("input1","Select What You Would Like to See",choices = c("Total Alcohol Consumption by Most/Least 10 Countries","Relationship of Happiness Score and Total Alcohol Consumption per Capita","Change on Happiness for Types of Drinks Per Capita","The Relationship of HDI and Happiness Score","The Relationship of HDI and Total Alcohol Usage Per Capita","Map of Happiness Score by Countries")),
                        htmlOutput("picture2"),
                        plotOutput("plot1"),
                        verbatimTextOutput("print1"),
                        htmlOutput("text1")
               ),
               tabPanel("Conclusion", fluid = TRUE,
                        htmlOutput("pictureconc"),
                        htmlOutput("textconc")
               ),
               tabPanel("Plot it Yourself!",fluid=TRUE,
                        sidebarLayout(
                            sidebarPanel(
                        radioButtons("plotinput1","Select Your First Variable! (For X-Axis)",choices = c("HappinessScore","HDI","Beer_PerCapita","Spirit_PerCapita","Wine_PerCapita","Total_PerCapita")),
                        radioButtons("plotinput2","Select Your Second Variable! (For Y-Axis)",choices = c("HappinessScore","HDI","Beer_PerCapita","Spirit_PerCapita","Wine_PerCapita","Total_PerCapita")),
                                     ),mainPanel(plotOutput("yourplot")))
                        ),
               
               
               tabPanel("About LIME", fluid = TRUE,
                        verbatimTextOutput("printlime"),
                        htmlOutput("picturelime"),
                        htmlOutput("names")
               ),
               tabPanel("References", fluid = TRUE,
                        htmlOutput("refheader"),
                        htmlOutput("references")
                        )
    ),
)

server <- function(input, output) {
    
    output$plot1 <- renderPlot({
        if(input$input1=="Total Alcohol Consumption by Most/Least 10 Countries"){
            
            top10 <- sqldf("select * from alcohap order by Total_PerCapita desc limit 10")
            topplot <- top10 %>% 
                ggplot(.,aes(x=Country,group=Country,fill=Country,y=Total_PerCapita)) + 
                geom_bar(stat="identity") + 
                geom_text(aes(label=Total_PerCapita), vjust=1.6, color="white", size=3.5) +
                labs(title = "Total Alcohol Consumption Per Capita", subtitle = "Grouped by Top 10 Countries", x = "Country",
                     y= "Total Consumption Per Capita (Liters)") +
                theme_classic() + 
                theme(axis.text.x=element_blank())
            
            least10 <- sqldf("select * from alcohap order by Total_PerCapita asc limit 10")
            leastplot <- least10 %>% 
                ggplot(.,aes(x=Country,group=Country,fill=Country,y=Total_PerCapita)) + 
                geom_bar(stat="identity") + 
                geom_text(aes(label=Total_PerCapita), vjust=1.6, color="white", size=3.5) +
                labs(title = "Total Alcohol Consumption Per Capita", subtitle = "Grouped by Least 10 Countries", x = "Country",
                     y= "Total Consumption Per Capita (Liters)") +
                theme_classic() + 
                theme(axis.text.x=element_blank())
            
            grid.arrange(topplot, leastplot, ncol=2)
        }
        else{
            if(input$input1=="Relationship of Happiness Score and Total Alcohol Consumption per Capita"){
                alcohap %>%
                    ggplot(aes(x=Total_PerCapita, y=HappinessScore)) +
                    geom_point() +
                    scale_x_continuous(name = "Total Per Capita" ) +
                    scale_y_continuous(name = "Happiness Score") +
                    labs(title = "Relationship of Happiness Score and Total Alcohol Consumption per Capita") +
                    geom_smooth(method = "lm", col = "magenta",se = TRUE) + 
                    theme_classic()
            }
            else{
                if(input$input1=="Change on Happiness for Types of Drinks Per Capita"){
                    beer <- alcohap %>%
                        ggplot(aes(x=HappinessScore, y=Beer_PerCapita)) +
                        geom_point() +
                        scale_y_continuous(name = "Beer per Capita (Liters)" ) +
                        scale_x_continuous(name = "Happiness Score") +
                        labs(title = "Relationship Between Happiness Score Beer Consumption") + 
                        theme_classic()
                    
                    
                    spirit <- alcohap %>%
                        ggplot(aes(x=HappinessScore, y=Spirit_PerCapita)) +
                        geom_point() +
                        scale_y_continuous(name = "Spirit per Capita (Liters)" ) +
                        scale_x_continuous(name = "Happiness Score") +
                        labs(title = "Relationship Between Happiness Score and Consumption of Spirits") + 
                        theme_classic()
                    
                    wine <- alcohap %>%
                        ggplot(aes(x=HappinessScore, y=Wine_PerCapita)) +
                        geom_point() +
                        scale_y_continuous(name = "Wine per Capita (Liters)" ) +
                        scale_x_continuous(name = "Happiness Score") +
                        labs(title = "Relationship Between Happiness Score and Consumption of Wine") + 
                        theme_classic()
                    
                    grid.arrange(beer, spirit, wine, ncol=3)
                }
                else{
                    if(input$input1=="Click Here to Learn More About Lime!"){
                        nateframe <- data.frame(Happiness.Level = c(20,500,1000),Progress.on.this.Page = c("1-Start","2-Middle","3-End"))
                        nateframe %>% 
                            ggplot(.,aes(x=Progress.on.this.Page,y=Happiness.Level)) +
                            geom_bar(stat="identity",color=c("darkred","darkblue","darkgreen"),fill = c("darkred","darkblue","darkgreen")) + 
                            theme_classic() +
                            labs(title = "Graph of Happiness Level Compared to Reading these Facts", subtitle="For Lime Facts")
                        
                    }
                    else{
                        if(input$input1=="The Relationship of HDI and Happiness Score"){
                            rq(alcohap$HappinessScore~alcohap$HDI,tau=0.5)
                            plot(alcohap$HappinessScore,alcohap$HDI,cex=.25,type="n",xlab="Happiness Score", ylab="HDI",main="The Relationship of\nHuman Development Index and Happiness Score")
                            points(alcohap$HappinessScore,alcohap$HDI,cex=.5,col="blue")
                            abline(rq(alcohap$HDI~alcohap$HappinessScore,tau=0.5),col="blue")
                            abline(lm(alcohap$HDI~alcohap$HappinessScore),lty=3,col="red")
                            taus <- c(.05,.1,.25,.75,.90,.95)
                            for( i in 1:length(taus)){
                                abline(rq(alcohap$HDI~alcohap$HappinessScore,tau=taus[i]),col="gray")
                                
                            }
                            
                        }
                        else{
                            if(input$input1=="The Relationship of HDI and Total Alcohol Usage Per Capita"){
                                reg2 <- rq(alcohap$HDI~alcohap$Total_PerCapita,tau = 0.5)
                                plot(alcohap$HDI,alcohap$Total_PerCapita,cex=0.25,type="n",xlab="Human Development",ylab="Total Per Capita",main="The Relationsip of Human Development Index and \nTotal Alcohol Usage Per Capita")
                                points(alcohap$HDI,alcohap$Total_PerCapita,cex=0.5,col="dark green")
                                abline(rq(alcohap$Total_PerCapita~alcohap$HDI,tau=0.5),col="dark blue")
                                abline(lm(alcohap$Total_PerCapita~alcohap$HDI),lty=1,col="red")
                                taus <- c(0.05,0.1,0.25,0.75,0.90,0.950)
                                for(i in 1:length(taus)){
                                    abline(rq(alcohap$Total_PerCapita~alcohap$HDI,tau=taus[i]),col="green")
                                }
                            }
                            else{
                                if(input$input1=="Map of Happiness Score by Countries"){
                                    mydata <- alcohap
                                    head(mydata)
                                    
                                    quantile(mydata$HappinessScore)
                                    
                                    mydata <- mydata %>% mutate(happiness_grp = case_when(HappinessScore >= 3  & HappinessScore <= 3.99 ~ '1',
                                                                                          HappinessScore >= 4  & HappinessScore <= 4.99 ~ '2',
                                                                                          HappinessScore >= 5  & HappinessScore <= 5.99 ~ '3',
                                                                                          HappinessScore >= 6  & HappinessScore <= 6.99 ~ '4',
                                                                                          HappinessScore >= 7 ~ '5'))
                                    mydata$country <- mydata$Country
                                    
                                    
                                    mydata$countrycodes <- countrycode(mydata$country, origin = 'country.name', destination = 'iso3c')
                                    
                                    a <- mydata$countrycodes
                                    b <- mydata$happiness_grp
                                    mymap <- data.frame(a,b)
                                    head(mymap)
                                    colnames(mymap) <- c("country", "happiness_score")
                                    
                                    
                                    mapping <- joinCountryData2Map(mymap, 
                                                                   joinCode = "ISO3",
                                                                   nameJoinColumn = "country")
                                    
                                    mapParams <- mapCountryData(mapping, 
                                                                nameColumnToPlot="happiness_score",
                                                                oceanCol = "azure2",
                                                                catMethod = "categorical",
                                                                missingCountryCol = gray(.8),
                                                                c("blue",
                                                                  "yellow",
                                                                  "red", "pink", 
                                                                  "green", "purple"),
                                                                addLegend = F,
                                                                mapTitle = "Happiness Levels by Countries",
                                                                border = NA)
                                    
                                    do.call(addMapLegendBoxes, c(mapParams,
                                                                 x = 'bottom',
                                                                 title = "Happiness Levels",
                                                                 horiz = TRUE,
                                                                 bg = "transparent",
                                                                 bty = "n"))
                                }
                                else{}
                            }
                        }
                    }
                }
            }
        }
    })
    
    output$print1 <- renderPrint({
        if(input$input1=="Total Alcohol Consumption by Most/Least 10 Countries"){
            summary(alcohap$Total_PerCapita)
        }
        else{
            if(input$input1=="Relationship of Happiness Score and Total Alcohol Consumption per Capita"){
                totalhaplm <- summary(lm((alcohap$Total_PerCapita~alcohap$HappinessScore)))
                totalhapcor <- cor(alcohap$Total_PerCapita,alcohap$HappinessScore,method="spearman")
                totalhap <- c(totalhaplm,totalhapcor)
                totalhap[c(4,9,10,12)]
                
            }
            else{
                if(input$input1=="Change on Happiness for Types of Drinks Per Capita"){
                    cortest1 <- cor.test(alcohap$HappinessScore,alcohap$Beer_PerCapita, method = "spearman")
                    cortest2 <- cor.test(alcohap$HappinessScore,alcohap$Spirit_PerCapita, method = "spearman")
                    cortest3 <- cor.test(alcohap$HappinessScore,alcohap$Wine_PerCapita, method = "spearman")
                    cortests <- c(cortest1[c("data.name","estimate")],cortest2[c("data.name","estimate")],cortest3[c("data.name","estimate")])
                    cortests
                }
                else{
                    if(input$input1=="Click Here to Learn More About Lime!"){
                        cat("summary(LIME)\nWe're so uninspired that we took our initials as our group name.")
                    }
                    else{
                        if(input$input1=="The Relationship of HDI and Happiness Score"){
                            summary(rq(alcohap$HappinessScore~alcohap$HDI,tau=0.5))
                        }
                        else{
                            if(input$input1=="The Relationship of HDI and Total Alcohol Usage Per Capita"){
                                reg2 <- rq(alcohap$HDI~alcohap$Total_PerCapita,tau = 0.5)
                                summary(reg2)
                            }
                            else{
                                if(input$input1=="Map of Happiness Score by Countries"){
                                    dfhappiness <- data.frame(Happiness.Level=c(1,2,3,4,5),Values=c("3.07-3.99","4.00-4.99","5.00-5.99","6.00-6.99","7.00-7.53"))
                                    dfhappiness
                                }
                            }
                        }
                    }
                }
            }
            
        }
    } 
    )
    output$text1 <- renderUI({
        if(input$input1=="Total Alcohol Consumption by Most/Least 10 Countries"){
            HTML(paste('<font size="+1">',"We can see from the summary table that minimum alcohol usage is 5 Liters on average and we can also see from the graphs that the value belongs to Comoros. The maximum consumption of 665 liters belongs to Czech Republic and the mean consumption is 300.8 liters per capita.",'<br/>','<br/>','</font>'))
        }
        else{
            if(input$input1=="Relationship of Happiness Score and Total Alcohol Consumption per Capita"){
                HTML(paste('<font size="+1">',"We can see from the p-values of the individual t-tests for Intercept and Happiness Score, and also from the overall value for F-test, that the linear model is appropriate for the data. But since the adjusted R-squared value is ~0.3, the model can only explain up to 30% of the data's variation.",'<br/>','<br/>', "Also, the Spearman's Correlation Coefficient between the two variables is ~0.55 which means that there is a moderately strong and significant relationship beteween total alcohol consumption and happiness level of a country.",'<br/>','<br/>','</font>'))
            }
            else{
                if(input$input1=="Change on Happiness for Types of Drinks Per Capita"){
                    HTML(paste('<font size="+1">',"As we can see from the tables, the correlation between happiness and beer consumption is the strongest with rho ~0.53 which is still only a moderately strong positive correlation.",'<br/>'," The weakest correlation is between spirit consumption and happiness score which is a moderately weak positive correlation.",'<br/>','<br/>','</font>'))
                }
                else{
                    if(input$input1=="Click Here to Learn More About Lime!"){
                        HTML(paste('<font size="+1">',"A lime is a hybrid citrus fruit.",'<br/>',"There are several species of citrus trees whose fruits are called limes, including the Persian lime, Key lime, kaffir lime, and desert lime.",'<br/>',"Limes were introduced to the western Mediterranean countries by returning Crusaders in the 12th and 13th centuries.",'<br/>',"The English word “lime” was derived, via Spanish then French, from the Arabic word lima (Persian: limu).",'<br/>',"Raw limes are 88% water, 10% carbohydrates and less than 1% each of fat and protein.",'<br/>',sep = '<br/>','</font>'))
                    }
                    else{
                        if(input$input1=="The Relationship of HDI and Happiness Score"){
                            HTML(paste('<font size="+1">',"Scatterplot and Quantile Regression Fit of the Happines Score and Human development index. The gray lines are the (0.05,0.1,0.25,0.75,0.90 and 0.95) quantile regression lines. The blue line indicates the best fitting (tau = 0.5) quantile regression line. Red line indicates the least square estimate for the conditional mean.",'<br/>','<br/>'," From the quantile regression summary, an equation of:",'<br/>',"<em>", 'HappinessScore = 0.90328+0.00629*HDI',"</em>",'<br/>'," can be obtained. ",'<br/>','<br/>',"The quantile regression coefficient tells us that for every one unit change in HDI  that the predicted value of happiness will increase by 0.00629.",'<br/>',"R squared is 0.682133 close to 1.Hence, it is a good fit and it does explain most of the variability in the response variable, Happiness Score.",'<br/>','<br/>','</font>'))
                        }
                        else{
                            if(input$input1=="The Relationship of HDI and Total Alcohol Usage Per Capita"){
                                HTML(paste('<font size="+1">',"Scatterplot and Quantile Regression Fit of the Human Development Index and Total Alcohol Usage Per Capita. The green lines are the (0.05,0.1,0.25,0.75,0.90 and 0.95) quantile regression lines. The blue line indicates the best fitting (tau = 0.5) quantile regression line. Red line indicates the least square estimate for the conditional mean.",'<br/>','<br/>'," From the quantile regression summary, an equation of:",'<br/>',"<em>", 'HDI = 575.62245+0.56122*TotalAlcoholusage',"</em>",'<br/>'," can be obtained. ",'<br/>','<br/>',"The quantile regression coefficient tells us that for every one unit change in Total Alcohol Consumption, the predicted value of happiness will increase by 0.56122.",'<br/>',"R squared is 0.5224320 so the fit is moderatly good, and it does explain half of the variability in the response variable, HDI.",'<br/>','<br/>','</font>'))   
                            }
                            else{
                                if(input$input1=="Map of Happiness Score by Countries"){
                                    HTML(paste('<font size="+1">',"It can be seen from the map that North America countries like ABD and Canada, North Europe countries like Sweden, Norway and Finland, and Australia have the highest happiness levels. In general, South American and European countries, again have high happiness levels. On the other hand, African countries have the lowest happiness levels.",'<br/>','<br/>','</font>'))
                                }
                            }
                        }
                    }
                    
                }
            }
            
        }
    })
    output$text2 <- renderPrint(
        print(alcohap[,input$input2])
    )
    output$picture1 <-
        renderText({
            c(
                '<img src="',
                "https://scontent.fesb3-2.fna.fbcdn.net/v/t1.0-9/102373405_1760286517443850_3987245271632314368_n.jpg?_nc_cat=105&_nc_sid=8024bb&_nc_oc=AQmsI5q75OF2Q5VLJMVpXcPyFCD98lqaqrcgPaz3_dbx6-c_q1icA7FIlL2nIbrwULU&_nc_ht=scontent.fesb3-2.fna&oh=afba5769322da8cee7e752affa107842&oe=5EFFDD8B",
                '">'
            )
        })
    output$picture2 <- renderText({
        if(input$input1=="Total Alcohol Consumption by Most/Least 10 Countries"){
            c(
                '<img src="',
                "https://scontent.fesb3-1.fna.fbcdn.net/v/t1.0-9/101670825_1760286564110512_7702657510435454976_n.jpg?_nc_cat=103&_nc_sid=8024bb&_nc_oc=AQkFu7XMjNG5TNncrymsiD2ErTXsKU_ieX3OuTWsMkbUMLeJ4tlq-R2aTWVzczSpm2c&_nc_ht=scontent.fesb3-1.fna&oh=48d5352a975675cb3935dcb467deb36b&oe=5EFC9F06",
                '">'
            )
        }
        else{
            if(input$input1=="Relationship of Happiness Score and Total Alcohol Consumption per Capita"){
                c(
                    '<img src="',
                    "https://scontent.fesb3-1.fna.fbcdn.net/v/t1.0-9/101587902_1760286570777178_3537889270385606656_n.jpg?_nc_cat=109&_nc_sid=8024bb&_nc_oc=AQmuIDcFLdnHyWhzZcgfi7FB357R68Wmp1jyIRWCs0BUs6PVBHbxLdnO6FIXoVxzpsI&_nc_ht=scontent.fesb3-1.fna&oh=a12a3e029d9f08c541eccdeb9b89f480&oe=5F003004",
                    '">'
                )
            }
            else{
                if(input$input1=="Change on Happiness for Types of Drinks Per Capita"){
                    c(
                        '<img src="',
                        "https://scontent.fesb3-1.fna.fbcdn.net/v/t1.0-9/82927367_1760286567443845_2893511225272958976_n.jpg?_nc_cat=110&_nc_sid=8024bb&_nc_oc=AQlIO2wjWds4wTp-kca-XBRbBKdK9_Lcmz8WMqJR9SqZ70-XDvlnhUWd8w_zSsL-Ujs&_nc_ht=scontent.fesb3-1.fna&oh=6b926c2c706fe10780d2024225d52902&oe=5EFE765D",
                        '">'
                    )
                }
                else{
                    if(input$input1=="The Relationship of HDI and Happiness Score"){
                        c(
                            '<img src="',
                            "https://scontent.fesb3-1.fna.fbcdn.net/v/t1.0-9/101984646_1760286627443839_6877915075391258624_n.jpg?_nc_cat=110&_nc_sid=8024bb&_nc_oc=AQl_J3GGf5CEmQWeJAAsZu-44n38sVR6tpVirTI-AXU__Rx9BlgSXpwrih4l-eco6Aw&_nc_ht=scontent.fesb3-1.fna&oh=39eba56003c92bc903443a78a451ad7b&oe=5EFFBC74",
                            '">'
                        )
                    }
                    else{
                        if(input$input1=="Map of Happiness Score by Countries"){
                            c(
                                '<img src="',
                                "https://scontent.fesb3-1.fna.fbcdn.net/v/t1.0-9/82874283_1760286634110505_8702578282660364288_n.jpg?_nc_cat=111&_nc_sid=8024bb&_nc_oc=AQk0wrGetoRSRovP0CCsAXf30JzFlDEMxu5bxyWI2bcvpi6xyPm7FerIlCN6X7aWY7A&_nc_ht=scontent.fesb3-1.fna&oh=5119ae0d5fd89df8467a584ab6f5e92d&oe=5EFF83C0",
                                '">'
                            )
                        }
                        else{
                            if(input$input1=="The Relationship of HDI and Total Alcohol Usage Per Capita"){
                                c(
                                    '<img src="',
                                    "https://scontent.fesb3-1.fna.fbcdn.net/v/t1.0-9/101597992_1760286637443838_262486316409683968_n.jpg?_nc_cat=100&_nc_sid=8024bb&_nc_oc=AQnkEpyAqEjRQISunlZoDjeODHszyT6uOEWSzMPBzjB0I21i2fP4PEpF7NXlvGWO3kA&_nc_ht=scontent.fesb3-1.fna&oh=8d4e9db31484601d2d9c4c055098f787&oe=5EFD82BB",
                                    '">'
                                )   
                            }
                        }
                    }
                }
            }
        }
    })
    output$picture3 <- renderText({
        c(
            '<img src="',
            "https://scontent.fesb3-1.fna.fbcdn.net/v/t1.0-9/101507471_1760295910776244_6081117097734176768_n.jpg?_nc_cat=103&_nc_sid=8024bb&_nc_oc=AQlbU5pKU0kd8lpsTsX6bASU84W46EzBHWNYxxzwpFxp4fBBL4bzuNOFoF8-_zkNG1Y&_nc_ht=scontent.fesb3-1.fna&oh=0127520312c131f4a3d8ace5c126ad90&oe=5EFEC01F",
            '">'
        )
    })
    output$printlime <- renderPrint(cat("summary(LIME)\nWe're so uninspired that we took our initials as our group name."))
    output$picturelime <- renderText({
        c(
            '<img src="',
            "https://scontent.fesb3-1.fna.fbcdn.net/v/t1.0-9/101881149_1760338254105343_2766261411695820800_o.jpg?_nc_cat=109&_nc_sid=8024bb&_nc_oc=AQnjIcUQnxVJcFd34pMXTA4o0_qqA4DXTuZwIH2Obm5TcTs5La2o_pXKPoXPvK7Ukag&_nc_ht=scontent.fesb3-1.fna&oh=6d5ca28eaa7c0142209333ee0b3b2a16&oe=5EFF4062",
            '">'
        )
    })
    output$pictureconc <- renderText({
        c(
            '<img src="',
            "https://scontent.fesb3-2.fna.fbcdn.net/v/t1.0-9/102708044_1760345094104659_893019942465568768_n.jpg?_nc_cat=106&_nc_sid=8024bb&_nc_oc=AQkpdtOxKs5AesvkbgZGRX0ZE5sUzQpffUmnGhEhWGylmSaT15MtL1xmSsq5HkAWP6c&_nc_ht=scontent.fesb3-2.fna&oh=c778831516f90c60b4761940a0b1ae24&oe=5EFF4148",
            '">'
        )
    })
    output$textconc <- renderUI({
        HTML(paste('<font size="+1">','<br/>','<br/>',"In conclusion, it was found that, the country that consumes wine, spirit and beer in total the most is Czech Republic, while the least is Comoros.",'<br/>','<br/>',"There is a moderately strong significant relationship between the total alcohol consumption and happiness levels of the countries.",'<br/>','<br/>',"Also, when looking at the types of alcohol individually, it was found that, beer consumption per capita has a stronger relationship with the happiness scores of the countries than wine and spirit per capita.",'<br/>','<br/>',"The relationship between human development index and hapiness score is strong and positive.",'<br/>','<br/>',"There is a moderately strong relationship between the total alcohol consumption and human development index.",'<br/>','<br/>',"According to the map, African countries have the lowest happiness scores while North American and European Countries has the highest happiness scores.",'<br/>','<br/>','</font>'))
    })
    output$yourplot <- renderPlot({
        plot(alcohap[,input$plotinput1],alcohap[,input$plotinput2],ann=FALSE,main="Here is your Plot")
    })
    output$names <- renderUI({
        HTML(paste('<font size="+1">','<br/>',"LIME Members:",'<br/>',"Levent Sarı - 2290930",'<br/>',"İpek Aydın - 2290526",'<br/>',"Miray Çınar - 2290609",'<br/>',"Ecenaz Tunç - 2290971",'<br/>','<br/>','</font>'))
    })
    output$references <- renderUI({
        HTML(paste('<font size="+1">','<br/>',"1.",'<i>',"Alcohol Consumption and Happiness",'</i>',"University of Sydney | MATH1005 | Semester 2, 2019 | Madsen Computer Lab 302, 11am-12pm","SID: 490357246, SID:490398799, SID:470430936","Retrieved from: https://www.kaggle.com/marcospessotto/happiness-and-alcohol-consumption",'<br/>',"2.",'<i>',"https://www.acsh.org/news/2016/07/01/the-relationship-between-alcohol-and-happiness",'</i>','<br/>',"3.",'<i>',"https://www.youtube.com/watch?v=B-EmeQg40wE",'</i>','<br/>',"4.",'<i>',"https://shiny.rstudio.com/tutorial/",'</i>','<br/>',"5.",'<i>',"https://bootswatch.com",'</i>','</font>'
            
        ))
    })
    output$refheader <- renderText({
        c(
            '<img src="',
            "https://scontent.fesb3-2.fna.fbcdn.net/v/t1.0-9/102378128_1762262880579547_5327386065715248250_n.jpg?_nc_cat=105&_nc_sid=8024bb&_nc_oc=AQndBzM6PhzyfsRMSDArLLk4r66BGm9BOP1xhVAd0hPy2ksQ5-pOcNZqybLtuNB7Omo&_nc_ht=scontent.fesb3-2.fna&oh=2ec96949fef070947ac1a969964e8435&oe=5F017448",
            '">'
        )
    })
    output$pictureapp <- renderText({
        c(
            '<img src="',
            "https://scontent.fesb3-2.fna.fbcdn.net/v/t1.0-9/102686964_1762310013908167_1811869359424263930_n.jpg?_nc_cat=101&_nc_sid=8024bb&_nc_oc=AQk5SMGVKEaOvaKGxAIPOsemj79umiwNqez1uQnqNBvMa1CIYe7KRlv_lHSm1heM_W0&_nc_ht=scontent.fesb3-2.fna&oh=42366c199fe0f6ee938f543f75408c7a&oe=5F007B4A",
            '">'
        )
    })
    
}


shinyApp(ui, server)
